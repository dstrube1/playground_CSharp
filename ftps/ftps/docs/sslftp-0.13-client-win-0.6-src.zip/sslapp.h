/* sslapp.h	- ssl application code
 *
 * Patched by SkyNick <skynick@stu.lipetsk.su>
 *
 * The modifications to support SSLeay were done by Tim Hudson
 * tjh@cryptsoft.com
 *
 * You can do whatever you like with these patches except pretend that
 * you wrote them.
 *
 */

#ifdef USE_SSL

#include <stdio.h>

#ifdef LINUX
#include <stdarg.h>
#endif

#include <openssl/crypto.h>

#if SSLEAY_VERSION_NUMBER >= 0x0800
#define SSLEAY8
#endif
 
#ifdef SSLEAY8
#define SSL_set_pref_cipher(c,n)        SSL_set_cipher_list(c,n)
#define ONELINE_NAME(X) X509_NAME_oneline(X,NULL,0)
#else
#define ONELINE_NAME(X) X509_NAME_oneline(X)
#endif
  
#ifdef SSLEAY8
#define OLDPROTO NOPROTO
#define NOPROTO
#include <openssl/bio.h>
#undef NOPROTO
#define NOPROTO OLDPROTO
#undef OLDPROTO
#endif
#include <openssl/buffer.h>

#include <openssl/x509.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

extern BIO *bio_err;
extern SSL *ssl_con;
extern SSL_CTX *ssl_ctx;
extern int ssl_debug_flag;
extern int ssl_active_flag;
extern int ssl_verify_flag;
/* SKYNICK extern int ssl_secure_flag; */
extern int ssl_verbose_flag;
extern int ssl_disabled_flag;
extern int ssl_cert_required;
extern int ssl_certsok_flag;
extern int ssl_quiet_flag;

extern char *ssl_log_file; 
extern char *ssl_cert_file; 
extern char *ssl_key_file;
extern char *ssl_cipher_list;
extern char *ssl_CA_file;
extern char *ssl_CA_path;
extern char *ssl_CRL_file;
extern char *ssl_CRL_path;

/* we hide all the initialisation code in a separate file now */
extern int do_ssleay_init();
/* for TLS/SSL debugging purposes */
extern void ssl_log_msg(BIO *bio, const char *fmt, ...);
extern void ssl_log_msgn(BIO *bio, const char *fmt, ...);
extern void ssl_log_vwarn(BIO *bio, const char *fmt, va_list ap);
extern void ssl_log_warn(BIO *bio, const char *fmt, ...);
extern void ssl_log_vwarn_debug(BIO *bio, const char *fmt, va_list ap);
extern void ssl_log_warn_debug(BIO *bio, const char *fmt, ...);
extern void ssl_log_err(BIO *bio, const char *fmt, ...);

extern int ssl_X509_cmp(X509 *x509_cert1, X509 *x509_cert2);

extern X509_STORE *ssl_X509_STORE_create(char *cpFile, char *cpPath);
extern int verify_cb_CRL(int ok, X509_STORE_CTX *ctx);

/* Try to turn on encryption of data connections during establishing secure
   connection with server */
extern int ssl_tryprot_flag;
extern void ssl_try_setprot();

#endif /* USE_SSL */
