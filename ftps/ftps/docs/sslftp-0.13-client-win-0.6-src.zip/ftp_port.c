#include <winsock.h>
#include <stdio.h>

char buff[4096],outbuff[512];
int err,i,outerr;
int buffptr = 0;
int outptr = 0;


int getsock(SOCKET s)
{
	/* Check for contents of buffer & refresh if empty */
	if (buff[buffptr] == '\0')
	{
		for (i=0;i<4096;i++) buff[i]='\0';
		err = recv(s,buff,sizeof(buff),0);
		buffptr = 0;
		if ((err == SOCKET_ERROR)||(err == 0))
			return -1;
	};

	return buff[buffptr++];
}

void putsock(SOCKET s, int c)
{
	outbuff[outptr++] = c;
	
	/* If packet is full then send & start a new one */
	if (outptr > 511)
	{
		outerr = send(s,outbuff,sizeof(outbuff),0);
		if (outerr == SOCKET_ERROR)
			fprintf(stderr,"Error sending data\n");
		outptr = 0;
		for (i=0;i<512;i++) outbuff[i]='\0';
	};

	return;
}

void flushsock(SOCKET s)
{
		outerr = send(s,outbuff,outptr,0);
		if (outerr == SOCKET_ERROR)
			fprintf(stderr,"Error sending data, code %i\n", WSAGetLastError());
		outptr = 0;
		for (i=0;i<512;i++) outbuff[i]='\0';
		return;
}

void sockprintf(SOCKET s, char *format, char c1, char c2, char c3)
{
	char tmpbuf[512];

	sprintf(tmpbuf,format,c1,c2,c3);
	send(s,tmpbuf,strlen(tmpbuf),0);
	return;
}
