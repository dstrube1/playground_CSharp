#include <stdio.h>
#include <fcntl.h>
#include <io.h>
#include <windows.h>


/* This has been hacked to work on Windows and doesn't
 * hide the password yet 
 */

/* Issue prompt and read reply with echo turned off */
char *getpass(prompt)
    const char * prompt;
{
/*	char *cp; */
	int c;
	static char pbuf[128];
	int bufnum = 64;
	FILE *tty;
	HANDLE hndin;
	BOOL err;
	DWORD oldmode, newmode;

	tty = stdin;

	fprintf(stderr, "%s", prompt); fflush(stderr);

/*	cp = pbuf;
	for (;;) {
		c = getc(tty);
		if(c == '\r' || c == '\n' || c == EOF)
			break;
		if (cp < &pbuf[127])
			*cp++ = c;
	}
	*cp = '\0';
*/ 
 	hndin = GetStdHandle(STD_INPUT_HANDLE);
	err = GetConsoleMode(hndin, &oldmode);
	newmode = oldmode & (~ENABLE_ECHO_INPUT);
	err = SetConsoleMode(hndin, newmode);
	err = ReadConsole(hndin, &pbuf, bufnum, &bufnum, NULL);
	err = SetConsoleMode(hndin, oldmode);

	for (c=0;c<128;c++)
		if (pbuf[c] == '\r' || pbuf[c] == '\n' || pbuf[c] == EOF)
			break;
	pbuf[c] = '\0';
  

	fprintf(stderr,"\r\n"); fflush(stderr);

	return(pbuf);
}

