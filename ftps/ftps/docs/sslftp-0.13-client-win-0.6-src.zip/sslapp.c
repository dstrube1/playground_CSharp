/* sslapp.c	- ssl application code
 *
 * Patched by SkyNick <skynick@stu.lipetsk.ru>
 *
 * The modifications to support SSLeay were done by Tim Hudson
 * tjh@cryptsoft.com
 *
 * You can do whatever you like with these patches except pretend that
 * you wrote them.
 *
 */

#ifdef USE_SSL

#include <string.h>
#include <stdarg.h>
#include "sslapp.h"

BIO *bio_err;
SSL *ssl_con;
SSL_CTX *ssl_ctx;
X509_STORE *x509st_CRL = NULL;

int ssl_debug_flag=0;
int ssl_active_flag=0;
int ssl_verify_flag=SSL_VERIFY_NONE;
int ssl_certsok_flag=0;
int ssl_cert_required=0;
int ssl_verbose_flag=0;
int ssl_disabled_flag=0;
char *ssl_cert_file=NULL;
char *ssl_key_file=NULL;
char *ssl_cipher_list=NULL;
char *ssl_log_file=NULL;
char *ssl_CA_file=NULL;
char *ssl_CA_path=NULL;
char *ssl_CRL_file=NULL;
char *ssl_CRL_path=NULL;

/* fwd decl */
static void client_info_callback();

int do_ssleay_init(server)
int server;
{
  char *p;

  /* make sure we have somewhere we can log errors to */
  if (bio_err==NULL) {
    if ((bio_err=BIO_new(BIO_s_file()))!=NULL) {
	if (ssl_log_file==NULL) {
	    /* SKYNICK: it's a workaround, but why does "stderr" construction not work???
	    Is it a bug of win32, VC or OpenSSL???
	    BIO_set_fp(bio_err,stderr,BIO_NOCLOSE);*/
	    BIO_write_filename(bio_err,"CON");
	} else {
	    if (BIO_write_filename(bio_err,ssl_log_file)<=0) {
	    /* not a lot we can do */
	    }
	}
    }
  }

  /* rather simple things these days ... the old SSL_LOG and SSL_ERR
   * vars are long gone now SSLeay8 has rolled around and we have 
   * a clean interface for doing things
   */
  if (ssl_debug_flag)
    ssl_log_msgn(bio_err, "SSL_DEBUG_FLAG on");

  /* init things so we will get meaningful error messages
   * rather than numbers 
   */
  SSL_load_error_strings();

#ifdef SSLEAY8
  SSLeay_add_ssl_algorithms();
  ssl_ctx=(SSL_CTX *)SSL_CTX_new(SSLv23_method());

  /* we may require a temp 512 bit RSA key because of the
   * wonderful way export things work ... if so we generate
   * one now!
   */
  if (server) {
    const char ctx_sid[]="BSDftpd-ssl";
    SSL_CTX_set_session_id_context(ssl_ctx, ctx_sid, strlen(ctx_sid));

    if (SSL_CTX_need_tmp_RSA(ssl_ctx)) {
      RSA *rsa;

      if (ssl_debug_flag)
	  ssl_log_msgn(bio_err, "Generating temp (512 bit) RSA key ...");
      rsa=RSA_generate_key(512,RSA_F4,NULL,NULL);
      if (ssl_debug_flag)
	  ssl_log_msgn(bio_err, "Generation of temp (512 bit) RSA key done");
   
      if (!SSL_CTX_set_tmp_rsa(ssl_ctx,rsa)) {
	  ssl_log_msgn(bio_err, "Failed to assign generated temp RSA key!");
      }

      RSA_free(rsa);
      if (ssl_debug_flag)
	  ssl_log_msgn(bio_err, "Assigned temp (512 bit) RSA key");
    }
  }

  /* also switch on all the interoperability and bug
   * workarounds so that we will communicate with people
   * that cannot read poorly written specs :-)
   */
  SSL_CTX_set_options(ssl_ctx,SSL_OP_ALL);

#else /* !SSLEAY8 */
  ssl_ctx=(SSL_CTX *)SSL_CTX_new();
#endif /* SSLEAY8 */

  /* the user can set whatever ciphers they want to use */
  if (ssl_cipher_list==NULL) {
      p=getenv("SSL_CIPHER");
      if (p!=NULL)
        SSL_CTX_set_cipher_list(ssl_ctx,p);
  } else
      SSL_CTX_set_cipher_list(ssl_ctx,ssl_cipher_list);

  /* for verbose we use the 0.6.x info callback that I got
   * eric to finally add into the code :-) --tjh
   */
  if (ssl_verbose_flag) {
      SSL_CTX_set_info_callback(ssl_ctx,client_info_callback);
  }

  /* Add in any certificates if you want to here ... */
  if (ssl_cert_file) {
      if (!SSL_CTX_use_certificate_file(ssl_ctx, ssl_cert_file, 
		      X509_FILETYPE_PEM)) {
	  ssl_log_err(bio_err, "Error loading %s",ssl_cert_file);
	  return(0);
      } else {
	  if (!ssl_key_file)
	      ssl_key_file = ssl_cert_file;
	  if (!SSL_CTX_use_RSAPrivateKey_file(ssl_ctx, ssl_key_file,
		      X509_FILETYPE_PEM)) {
	      ssl_log_err(bio_err, "Error loading %s",ssl_cert_file);
	      return(0);
	  }
      }
  }

#ifdef SSLEAY8
  /* Check if certificate locations specified in command-line or environment.
   * Command-line values will override environment ones.
   *
   * CApath is unavailable in Windows port due to unavailability of
   * symlinks in Windows
   */
  SSL_CTX_load_verify_locations(ssl_ctx, 
        ssl_CA_file ? ssl_CA_file : getenv(X509_get_default_cert_file_env()),
	NULL);

  /* Check if CRL locations specified in command-line or environment.
   * Command-line values will override environment ones.
   *
   * CRLpath is unavailable in Windows port due to unavailability of
   * symlinks in Windows
   */
  x509st_CRL = ssl_X509_STORE_create(
        ssl_CRL_file ? ssl_CRL_file : getenv("SSL_CRL_FILE"),
	NULL);
#else
  SSL_set_default_verify_paths(ssl_ctx);
#endif

  SSL_CTX_set_verify(ssl_ctx,ssl_verify_flag,verify_cb_CRL);

  return(1);
}


static void client_info_callback(s,where,ret)
SSL *s;
int where;
int ret;
{
  if (where==SSL_CB_CONNECT_LOOP) {
    ssl_log_msgn(bio_err,"SSL_connect:%s %s",
		SSL_state_string(s),SSL_state_string_long(s));
  } else if (where==SSL_CB_CONNECT_EXIT) {
    if (ret == 0) {
      ssl_log_msgn(bio_err,"SSL_connect:failed in %s %s",
		    SSL_state_string(s),SSL_state_string_long(s));
    } else if (ret < 0) {
      ssl_log_msgn(bio_err,"SSL_connect:error in %s %s",
		    SSL_state_string(s),SSL_state_string_long(s));
    }
  }
}

/*
 * Certificate Revocation List (CRL) Storage Support
 *
 * CRL support is bases on the similar CRL support developed by
 * Ralf S. Engelschall <rse@engelschall.com> for use in the
 * mod_ssl project (http://www.modssl.org/).
 */

/* Initialize X509_STORE structure (which holds the tables etc for verification
 * stuff).
 * arguments:
 *	cpFile - a file of CRLs in PEM format
 *	cpPath - a directory containing CRLs in PEM format and its hashes.
 * return:
 *	the pointer to X509_STORE structure or NULL if failed.
 * notes:
 *	This function is very similar to X509_STORE_load_locations(),
 *	the only principal difference is that return values of 
 *	X509_LOOKUP_*() calls aren't checked.
 */
X509_STORE *
ssl_X509_STORE_create(char *cpFile, char *cpPath)
{
    X509_STORE *pStore;
    X509_LOOKUP *pLookup;

    if (cpFile == NULL && cpPath == NULL)
        return NULL;
    if ((pStore = X509_STORE_new()) == NULL)
        return NULL;
    if (cpFile != NULL) {
        if ((pLookup = X509_STORE_add_lookup(pStore, X509_LOOKUP_file())) == NULL) {
            X509_STORE_free(pStore);
            return NULL;
        }
        X509_LOOKUP_load_file(pLookup, cpFile, X509_FILETYPE_PEM);
    }
    if (cpPath != NULL) {
        if ((pLookup = X509_STORE_add_lookup(pStore, X509_LOOKUP_hash_dir())) == NULL) {
            X509_STORE_free(pStore);
            return NULL;
        }
        X509_LOOKUP_add_dir(pLookup, cpPath, X509_FILETYPE_PEM);
    }
    return pStore;
}

/* This function is a wrapper around X509_STORE_get_by_subject().
 * Return values are the same, arguments nType, pName and pObj are the same
 * too, pStore is used for initialization of X509_STORE_CTX structure
 * which is used while validating a single certificate.
 */
int
ssl_X509_STORE_lookup(X509_STORE *pStore, int nType,
			X509_NAME *pName, X509_OBJECT *pObj)
{
    X509_STORE_CTX pStoreCtx;
    int rc;

    X509_STORE_CTX_init(&pStoreCtx, pStore, NULL, NULL);
    rc = X509_STORE_get_by_subject(&pStoreCtx, nType, pName, pObj);
    X509_STORE_CTX_cleanup(&pStoreCtx);
    return rc;
}

/* Certificate verify callback function which performs CRL-based revocation
 * checks. See SSL_CTX_set_verify() documentation for more information.
 * Reports next verification errors (see verify(1) for description):
 *	X509_V_ERR_CRL_SIGNATURE_FAILURE
 *	X509_V_ERR_ERROR_IN_CRL_NEXT_UPDATE_FIELD
 *	X509_V_ERR_CRL_HAS_EXPIRED
 *	X509_V_ERR_CERT_REVOKED
 *
 * Comments written by Ralf S. Engelschall <rse@engelschall.com>.
 */
int
verify_cb_CRL(int ok, X509_STORE_CTX *ctx)
{
    X509_OBJECT obj;
    X509_NAME *subject;
    X509_NAME *issuer;
    X509 *xs;
    X509_CRL *crl;
    X509_REVOKED *revoked;
    int i, n, rc;

    /*
     * Unless a revocation store for CRLs was created we
     * cannot do any CRL-based verification, of course.
     */
    if (!x509st_CRL)
        return ok;

    /*
     * Determine certificate ingredients in advance
     */
    xs      = X509_STORE_CTX_get_current_cert(ctx);
    subject = X509_get_subject_name(xs);
    issuer  = X509_get_issuer_name(xs);

    /*
     * OpenSSL provides the general mechanism to deal with CRLs but does not
     * use them automatically when verifying certificates, so we do it
     * explicitly here. We will check the CRL for the currently checked
     * certificate, if there is such a CRL in the store.
     *
     * We come through this procedure for each certificate in the certificate
     * chain, starting with the root-CA's certificate. At each step we've to
     * both verify the signature on the CRL (to make sure it's a valid CRL)
     * and it's revocation list (to make sure the current certificate isn't
     * revoked).  But because to check the signature on the CRL we need the
     * public key of the issuing CA certificate (which was already processed
     * one round before), we've a little problem. But we can both solve it and
     * at the same time optimize the processing by using the following
     * verification scheme (idea and code snippets borrowed from the GLOBUS
     * project):
     *
     * 1. We'll check the signature of a CRL in each step when we find a CRL
     *    through the _subject_ name of the current certificate. This CRL
     *    itself will be needed the first time in the next round, of course.
     *    But we do the signature processing one round before this where the
     *    public key of the CA is available.
     *
     * 2. We'll check the revocation list of a CRL in each step when
     *    we find a CRL through the _issuer_ name of the current certificate.
     *    This CRLs signature was then already verified one round before.
     *
     * This verification scheme allows a CA to revoke its own certificate as
     * well, of course.
     */

    /*
     * Try to retrieve a CRL corresponding to the _subject_ of
     * the current certificate in order to verify it's integrity.
     */
    memset((char *)&obj, 0, sizeof(obj));
    rc = ssl_X509_STORE_lookup(x509st_CRL, X509_LU_CRL, subject, &obj);
    crl = obj.data.crl;
    if (rc > 0 && crl != NULL) {
        /*
         * Verify the signature on this CRL
         */
        if (X509_CRL_verify(crl, X509_get_pubkey(xs)) <= 0) {
            X509_STORE_CTX_set_error(ctx, X509_V_ERR_CRL_SIGNATURE_FAILURE);
            X509_OBJECT_free_contents(&obj);
            return 0;
        }

        /*
         * Check date of CRL to make sure it's not expired
         */
        i = X509_cmp_current_time(X509_CRL_get_nextUpdate(crl));
        if (i == 0) {
            X509_STORE_CTX_set_error(ctx, X509_V_ERR_ERROR_IN_CRL_NEXT_UPDATE_FIELD);
            X509_OBJECT_free_contents(&obj);
            return 0;
        }
        if (i < 0) {
            X509_STORE_CTX_set_error(ctx, X509_V_ERR_CRL_HAS_EXPIRED);
            X509_OBJECT_free_contents(&obj);
            return 0;
        }
        X509_OBJECT_free_contents(&obj);
    }

    /*
     * Try to retrieve a CRL corresponding to the _issuer_ of
     * the current certificate in order to check for revocation.
     */
    memset((char *)&obj, 0, sizeof(obj));
    rc = ssl_X509_STORE_lookup(x509st_CRL, X509_LU_CRL, issuer, &obj);
    crl = obj.data.crl;
    if (rc > 0 && crl != NULL) {
        /*
         * Check if the current certificate is revoked by this CRL
         */
        n = sk_X509_REVOKED_num(X509_CRL_get_REVOKED(crl));
        for (i = 0; i < n; i++) {
            revoked = sk_X509_REVOKED_value(X509_CRL_get_REVOKED(crl), i);
            if (ASN1_INTEGER_cmp(revoked->serialNumber, X509_get_serialNumber(xs)) == 0) {
                X509_STORE_CTX_set_error(ctx, X509_V_ERR_CERT_REVOKED);
                X509_OBJECT_free_contents(&obj);
                return 0;
            }
        }
        X509_OBJECT_free_contents(&obj);
    }
    return ok;
}

/*
 * Compare two X509 certificates.
 * return:
 *	 1 - certificates are not NULL and equal
 *	 0 - certificates are not NULL and differ
 *	-1 - both certificates are NULL
 *	-2 - x509_cert1 is NULL, x509_cert2 is not NULL
 *	-3 - x509_cert1 in not NULL, x509_cert2 is NULL
 */
int
ssl_X509_cmp(X509 *x509_cert1, X509 *x509_cert2)
{
    /* X509_cmp() will crash if any of its args are NULL
     */
    if (x509_cert1!=NULL) {
	if (x509_cert2==NULL) {
	    return -3; /* x509_cert1 in not NULL, x509_cert2 is NULL */
	} else {
	    if (X509_cmp(x509_cert1, x509_cert2)) {
		return 0; /* certificates are differ */
	    } else {
		return 1; /* certificates are equal */
	    }
	}
    } else {
	if (x509_cert2==NULL) {
	    return -1; /* both certificates are NULL */
	} else {
	    return -2; /* x509_cert1 is NULL, x509_cert2 is not NULL */
	}
    }
}

/*
 * log error and debug information
 */

/* log message
 */
void ssl_log_msg(BIO *bio, const char *fmt, ...)
{
  va_list ap;
  char outputbuf[2048];

  va_start(ap,fmt);

  (void)vsprintf(outputbuf, fmt, ap);
  BIO_printf(bio, outputbuf);
  BIO_flush(bio);

  va_end(ap);
}

/* log message appended by newline
 */
void ssl_log_msgn(BIO *bio, const char *fmt, ...)
{
  va_list ap;
  char outputbuf[2048];

  va_start(ap,fmt);

  (void)vsprintf(outputbuf, fmt, ap);
  BIO_printf(bio, "%s\r\n", outputbuf);
  BIO_flush(bio);

  va_end(ap);
}

/* log message appended by reason of the last error code from SSL error queue
 * and removes that code.
 */
void ssl_log_vwarn(BIO *bio, const char *fmt, va_list ap)
{
  char outputbuf[2048];

  (void)vsprintf(outputbuf, fmt, ap);
  BIO_printf(bio, "%s: %s\r\n", outputbuf,
	    ERR_reason_error_string(ERR_get_error()));
  BIO_flush(bio);
}

void ssl_log_warn(BIO *bio, const char *fmt, ...)
{
  va_list ap;

  va_start(ap,fmt);
  ssl_log_vwarn(bio, fmt, ap);
  va_end(ap);
}

/* log message appended by human-readable string represinting the last
 * error code from SSL error queue and removes it.
 */
void ssl_log_vwarn_debug(BIO *bio, const char *fmt, va_list ap)
{
  char outputbuf[2048];

  (void)vsprintf(outputbuf, fmt, ap);
  BIO_printf(bio, "%s: %s\r\n", outputbuf,
	    ERR_error_string(ERR_get_error(),NULL));
  BIO_flush(bio);
}

void ssl_log_warn_debug(BIO *bio, const char *fmt, ...)
{
  va_list ap;

  va_start(ap,fmt);
  ssl_log_vwarn_debug(bio, fmt, ap);
  va_end(ap);
}

/* log message with verbosity level depending on the SSL debug state
 */
void ssl_log_err(BIO *bio, const char *fmt, ...)
{
  va_list ap;

  va_start(ap,fmt);

  if (ssl_debug_flag) {
    ssl_log_vwarn_debug(bio, fmt, ap);
  } else {
    ssl_log_vwarn(bio, fmt, ap);
  }

  va_end(ap);
}

#else /* !USE_SSL */

/* something here to stop warnings if we build without TLS/SSL support */
static int dummy_func()
{
  return 0;
}

#endif /* USE_SSL */
