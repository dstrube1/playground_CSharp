/* ssl_port.h    - standard porting things 
 *
 * Patched by SkyNick <skynick@stu.lipetsk.ru>
 *
 * The modifications to support SSLeay were done by Tim Hudson
 * tjh@mincom.oz.au
 *
 * You can do whatever you like with these patches except pretend that
 * you wrote them. 
 *
 */

#ifndef HEADER_SSL_PORT_H
#define HEADER_SSL_PORT_H

/*
 * SSL security flags
 */
#define SSL_USE_NONSECURE	0x01 /* non-secure mode */
#define SSL_USE_COMPAT		0x02 /* FTP-SSL compatibility mode */
#define SSL_USE_TLS		0x04 /* RFC2228 compliant FTP-TLS mode */
#define SSL_ENABLED		0x06 /* SSL_USE_TLS | SSL_USE_COMPAT */
extern int ssl_secure_flags;

#ifdef USE_SSL

#include <stdio.h>

/* SKYNICK #define OLDPROTO NOPROTO
#define NOPROTO */
#include "openssl/buffer.h"
/* SKYNICK #undef NOPROTO
#define NOPROTO OLDPROTO */

#include "openssl/x509.h"
#include "openssl/ssl.h"

extern SSL *ssl_con;
extern SSL_CTX *ssl_ctx;
extern int ssl_debug_flag;
extern int ssl_active_flag;

extern int ssl_compat_flag;
extern int PBSZ_used_flag;

extern int ssl_encrypt_data;
extern SSL *ssl_data_con;
extern int ssl_data_active_flag;

extern int ssl_certsok_flag;
extern int ssl_verify_flag;

extern void ssl_reinit();

extern int set_ssl_trace(SSL *s);

/* SKYNICK extern FILE *cin, *cout; */

#define is_ssl_fd(X,Y)    ( (SSL_get_fd((X))==0) || \
                            (SSL_get_fd((X))==1) || \
                            (SSL_get_fd((X))==pdata) || \
			    (SSL_get_fd((X))==(Y)) \
			  )

#define is_ssl_fp(X,Y)    ( ( (SSL_get_fd((X))==0) && (fileno((Y))==0) ) || \
                            ( (SSL_get_fd((X))==1) && (fileno((Y))==1) ) || \
                            ( (SSL_get_fd((X))==pdata) && \
			    			  (fileno((Y))==pdata) ) || \
			    (SSL_get_fd((X))==fileno(Y)) \
			  )

/* SKYNICK */
extern int getsock();
extern void putsock(), flushsock();
/**/

/* these macros make things much easier to handle ... */

#define FFLUSH(X)         (ssl_active_flag && (((X)==cin)||((X)==cout)) ? 1 : fflush((X)) )

/* SKYNICK #define GETC(X)           (ssl_active_flag && (((X)==cin)||((X)==cout)) ? ssl_getc(ssl_con) : getsock((X)) ) */
#define GETC(X)           (ssl_active_flag && ((X)==s) ? ssl_getc(ssl_con) : getsock((X)) )

/* SKYNICK #define DATAGETC(X)       (ssl_data_active_flag && ((fileno(X)==data)||(fileno(X)==pdata)) ? ssl_getc(ssl_data_con) : getsock((X)) ) */
#define DATAGETC(X)       (ssl_data_active_flag && ((X)==data) ? ssl_getc(ssl_data_con) : getsock((X)) )
/* SKYNICK #define DATAPUTC(X,Y)     (ssl_data_active_flag && ((fileno(Y)==data)||(fileno(Y)==pdata)) ? ssl_putc(ssl_data_con,(X)) : putsock((X),(Y)) ) */
#define DATAPUTC(X,Y)     (ssl_data_active_flag && ((Y)==data) ? ssl_putc(ssl_data_con,(X)) : putsock((Y),(X)) )
/* SKYNICK #define DATAFLUSH(X)      (ssl_data_active_flag && ((fileno(X)==data)||(fileno(X)==pdata)) ? ssl_putc_flush(ssl_data_con) : flushsock((X)) ) */
#define DATAFLUSH(X)      (ssl_data_active_flag && ((X)==data) ? ssl_putc_flush(ssl_data_con) : flushsock((X)) )

#else

#define GETC(X)           getc((X))
#define DATAGETC(X)       getc((X))
#define DATAPUTC(X,Y)     putc((X),(Y))
#define DATAFLUSH(X)      fflush((X))
#define FFLUSH(X)         fflush((X))

#endif /* USE_SSL */

#endif /*  HEADER_SSL_PORT_H */
