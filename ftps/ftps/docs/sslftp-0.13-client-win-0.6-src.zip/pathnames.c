/*-
 * Copyright (c) 2002 Nick Leuta
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <winsock.h>

char _PATH_TMP[1024];
char _SHELL[1024];
char _HOME[1024];

/*
 * Setting platform-depended pathes
 */
void SetPathNames() {
OSVERSIONINFO osvi;
char *tmpstr;

	/* set "typical" values for SHELL and PATH_TMP depending to Platform ID */
	/* OSVERSIONINFO initialization */
	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx((OSVERSIONINFO*)&osvi);
 
	/* Platform selection */
	switch (osvi.dwPlatformId) {
		case VER_PLATFORM_WIN32_NT:      /* Windows NT */
			strcpy(_PATH_TMP, "C:\\temp\\ftpXXXXXX");
			strcpy(_SHELL, "c:\\winnt\\system32\\cmd.exe");
			break;
		case VER_PLATFORM_WIN32_WINDOWS: /* Windows 95/98 */
		default:
			strcpy(_PATH_TMP, "C:\\windows\\temp\\ftpXXXXXX");
			strcpy(_SHELL, "c:\\windows\\command.com");
			break;
	}

	/* set default value for HOME */
	strcpy(_HOME, ".");

	/* try override "typical" values from environment variables */
	tmpstr = getenv("TEMP");
	if (tmpstr != NULL) {
		strcpy(_PATH_TMP, tmpstr);
		strcat(_PATH_TMP, "\\ftpXXXXXX");
	}
	tmpstr = getenv("COMSPEC");
	if (tmpstr != NULL) {
		strcpy(_SHELL, tmpstr);
	}
	/* try to override HOME from environment variables */
	tmpstr = getenv("USERPROFILE"); /* On Windows NT it's a path to location of 
										user's profile */
	if (tmpstr != NULL) {
		strcpy(_HOME, tmpstr);
	}
	tmpstr = getenv("HOME");        /* UNIX default variable; if set will
										override "USERPROFILE" */
	if (tmpstr != NULL) {
		strcpy(_HOME, tmpstr);
	}
}