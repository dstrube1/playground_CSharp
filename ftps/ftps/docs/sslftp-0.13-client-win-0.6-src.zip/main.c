/* 
 * The modifications to support SSLeay were done by Tim Hudson
 * tjh@cryptsoft.com
 *
 * You can do whatever you like with these patches except pretend that
 * you wrote them. 
 *
 * Email ssl-users-request@lists.cryptsoft.com to get instructions on how to
 * join the mailing list that discusses SSLeay and also these patches.
 *
 */

/*
 * Copyright (c) 1985, 1989 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef lint
char copyright[] =
"@(#) Copyright (c) 1985, 1989 Regents of the University of California.\n\
 All rights reserved.\n";
#endif /* not lint */

#ifndef lint
static char sccsid[] = "@(#)main.c	5.18 (Berkeley) 3/1/91";
#endif /* not lint */

/*
 * FTP User Program -- Command Interface.
 */
#include "ftp_var.h"
#include <winsock.h>
#include <sys/types.h>

#include "arpa/ftp.h"

#include <signal.h>
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <io.h>
#define SIGPIPE 13

extern void setpeer();
extern void pswitch();
extern void quit();
void makeargv();
void cmdscanner();
void	intr(int), lostpeer(int);
extern	char home[1024];

#ifdef USE_SSL

#include "sslapp.h"
#include "ssl_port.h"

/* SKYNICK */
#include <openssl/err.h>
#include "pathnames.h"
/**/
#if 0
SSL *ssl_con;
#endif
SSL *ssl_data_con;
int ssl_data_active_flag=0;

/* Data connection protection control for RFC2228 compliance */
int ssl_encrypt_data=0; /* RFC2228: default state is "Clear" */
int PBSZ_used_flag=0;   /* RFC2228: PBSZ must be used before first PROT */
int ssl_compat_flag=0;  /* for compatibility with early implementations of
							SSL upgrade */

int ssl_secure_flags=(SSL_ENABLED|SSL_USE_NONSECURE); /* Enable all modes */

#if 0
static void client_info_callback(s,where,ret)
SSL *s;
int where;
int ret;
{
        if (where == SSL_CB_CONNECT_LOOP) {
                fprintf(stderr,"SSL_connect:%s %s\n",SSL_state_string(s),SSL_state_string_long(s));
        } else if (where == SSL_CB_CONNECT_EXIT) {
                if (ret == 0) {
                        fprintf(stderr,"SSL_connect:failed in %s %s\n",
                                SSL_state_string(s),SSL_state_string_long(s));
                } else if (ret < 0) {
                        fprintf(stderr,"SSL_connect:error in %s %s\n",
                                SSL_state_string(s),SSL_state_string_long(s));
                }
        }
}
#endif

long bio_dump_cb(bio,cmd,argp,argi,argl,ret)
BIO *bio;
int cmd;
char *argp;
int argi;
long argl;
long ret;
        {
        BIO *out;

/*
        out=(BIO *)BIO_get_callback_arg(bio);
*/
	out=bio_err;
        if (out == NULL) return(ret);

        if (cmd == (BIO_CB_READ|BIO_CB_RETURN))
                {
                BIO_printf(out,"read from %08X (%d bytes => %ld (%X))\n",
                        bio,argi,ret,ret);
                BIO_dump(out,argp,(int)ret);
		BIO_flush(out);
                }
        else if (cmd == (BIO_CB_WRITE|BIO_CB_RETURN))
                {
                BIO_printf(out,"write to %08X (%d bytes => %ld (%X))\n",
                        bio,argi,ret,ret);
                BIO_dump(out,argp,(int)ret);
		BIO_flush(out);
                }
        return( (cmd & BIO_CB_RETURN) ? ret : 1);
        }

int set_ssl_trace(SSL *con) 
{
    if (con!=NULL) {
		if (ssl_debug_flag) {
			BIO_set_callback(SSL_get_rbio(con),bio_dump_cb);
			BIO_set_callback_arg(SSL_get_rbio(con),bio_err);
		}
    }
    return 0;
}

#endif /* USE_SSL */

#ifdef USE_SOCKS
int socks_flag=1;        /* socks usage is now the default */
#endif /* USE_SOCKS */

#ifdef PASVHACK
int pasv_hack=0;
#endif /* PASVHACK */

void main(argc, argv)
	char *argv[];
{
	register char *cp;
	int top;
/*	struct passwd *pw = NULL;
	char homedir[1024];	*/
	char *optarg;
	char *argv0;
	int err;
	WORD wVersionRequested;
	WSADATA WSAdata;

	argv0=argv[0];

	/* Set pathnames */
	SetPathNames();


	doglob = 1;
	interactive = 1;
	autologin = 1;
	argc--, argv++;
	while (argc > 0 && **argv == '-') {
	        optarg=*(argv+1);
		for (cp = *argv + 1; *cp; cp++)
			switch (*cp) {

			case 'd':
				options |= SO_DEBUG;
				debug++;
				break;
			
			case 'v':
				verbose++;
				break;

			case 't':
				trace++;
				break;

			case 'i':
				interactive = 0;
				break;

			case 'n':
				autologin = 0;
				break;

			case 'g':
				doglob = 0;
				break;
#ifdef USE_SSL
			case 'z':
				if ( (strcmp(optarg, "tls") == 0 ) || 
				     (strcmp(optarg, "nossl") == 0 ) ) {
					ssl_secure_flags|=SSL_USE_TLS;
					ssl_secure_flags&=(SSL_USE_COMPAT^0xff);
				}
				if ( (strcmp(optarg, "ssl") == 0 ) || 
				     (strcmp(optarg, "notls") == 0 ) ) {
				    ssl_secure_flags|=SSL_USE_COMPAT;
					ssl_secure_flags&=(SSL_USE_TLS^0xff);
				}
				if (strcmp(optarg, "secure") == 0 ) {
				    ssl_secure_flags|=SSL_ENABLED;
					ssl_secure_flags&=(SSL_USE_NONSECURE^0xff);
				}
				/* disable *all* ssl stuff */
				if (strcmp(optarg, "nosecure") == 0 ) {
				    ssl_secure_flags|=SSL_USE_NONSECURE;
					ssl_secure_flags&=(SSL_ENABLED^0xff);
				}
				if (strncmp(optarg, "verify=", strlen("verify=")) == 0 ) {
		    	    switch ( atoi(optarg+strlen("verify=")) ) {
					case 0:
						ssl_verify_flag = SSL_VERIFY_NONE;
						break;
					case 1:
						ssl_verify_flag = SSL_VERIFY_PEER;
						break;
					default:
						fprintf(stderr, "unknown verify level \"%d\" ignored",
								atoi(optarg+strlen("verify=")));
						fflush(stderr);
					}
				}
				if (strncmp(optarg, "cert=", strlen("cert=")) == 0 ) {
				    ssl_cert_file=optarg+strlen("cert=");
				}
				if (strncmp(optarg, "key=", strlen("key=")) == 0 ) {
				    ssl_key_file=optarg+strlen("key=");
				}
				if (strncmp(optarg, "cipher=", strlen("cipher=")) == 0 ) {
					ssl_cipher_list=optarg+strlen("cipher=");
				}
				if (strncmp(optarg, "CAfile=", strlen("CAfile=")) == 0 ) {
					ssl_CA_file=optarg+strlen("CAfile=");
				}
				if (strncmp(optarg, "CRLfile=", strlen("CRLfile=")) == 0 ) {
					ssl_CRL_file=optarg+strlen("CRLfile=");
				}
				/* CApath and CRLpath are unavailable in Windows port due to unavailability
				of symlinks in Windows */
				if (strncmp(optarg, "logfile=", strlen("logfile=")) == 0 ) {
					ssl_log_file=optarg+strlen("logfile=");
				}
				if (strcmp(optarg, "debug") == 0 ) {
				    ssl_debug_flag=1;
				}
				if (strcmp(optarg, "noprot") == 0 ) {
				    ssl_tryprot_flag=0;
				}
/* SKYNICK - disabled until tested
				if (strcmp(optarg, "verbose") == 0 ) {
				    ssl_verbose_flag=1;
				}
*/
				if (strcmp(optarg, "socks") == 0 ) {
#ifdef USE_SOCKS
				    socks_flag=1;
#else /* !USE_SOCKS */
                                    fprintf(stderr,"No SOCKS support\n");
				    fflush(stderr);
#endif /* USE_SOCKS */
				}
				if ( (strcmp(optarg, "!socks") == 0 ) || 
				     (strcmp(optarg, "nosocks") == 0 ) )  {
#ifdef USE_SOCKS
				    socks_flag=0;
#else /* !USE_SOCKS */
                                    fprintf(stderr,"No SOCKS support\n");
				    fflush(stderr);
#endif /* USE_SOCKS */
				}
                                if ( (strcmp(optarg, "!pasv") == 0 ) ||
                                     (strcmp(optarg, "nopasv") == 0 ) ) {
#ifdef PASVHACK
                                    pasv_hack=0;
#else /* !PASVHACK */
                                    fprintf(stderr,"No PASVHACK support\n");
				    fflush(stderr);
#endif /* PASVHACK */
                                }

                                /* we have swallowed an extra arg */
				argc--;
				argv++;
				break;
#endif /* USE_SSL */

#ifndef USE_SSL
                case 'z':
                        if (strcmp(optarg, "socks") == 0 ) {
#ifdef USE_SOCKS
                            socks_flag=1;
#else /* !USE_SOCKS */
                            fprintf(stderr,"No SOCKS support\n");
                            fflush(stderr);
#endif /* USE_SOCKS */
                        }
			if ( (strcmp(optarg, "!socks") == 0 ) || 
			     (strcmp(optarg, "nosocks") == 0 ) )  {
#ifdef USE_SOCKS
                            socks_flag=0;
#else /* !USE_SOCKS */
                            fprintf(stderr,"No SOCKS support\n");
                            fflush(stderr);
#endif /* USE_SOCKS */
                        }
                        if (strcmp(optarg, "socks") == 0 ) {
                            socks_flag=1;
                        }
                        break;
#endif /* !USE_SSL */



			default:
				fprintf(stdout,
				  "ftp: %c: unknown option\n", *cp);
				exit(1);
			}
		argc--, argv++;
	}

#ifdef USE_SOCKS
        if (socks_flag) 
	    SOCKSinit(argv0);
#endif /* USE_SOCKS */

    /* this was moved from before the arg processing to here
	 * as if we build for socks then it wipes out the service
	 * area with the getservbyname return for "socks" ... the
	 * joys of a single static area and not copying the 
	 * results of a lookup --tjh
	 */


	wVersionRequested = MAKEWORD( 1, 1 );
	err = WSAStartup( wVersionRequested, &WSAdata );
	if ( err != 0 ) {
		printf("Error on WSA startup");
 		return;
	}
	if ( LOBYTE( WSAdata.wVersion ) != 1 ||
  		HIBYTE( WSAdata.wVersion ) != 1 ) {
		printf("Winsock doesn't support this version");
 		WSACleanup( );
 		return; 
	}


	sp = getservbyname("ftp", "tcp"); 
/*	sp = (struct servent *) malloc(sizeof(struct servent));
	sp->s_name = "ftp";
	sp->s_aliases = NULL;
	sp->s_port = 21;
	sp->s_proto = "tcp";
*/
	if (sp == 0) {
		fprintf(stderr, "ftp: ftp/tcp: unknown service\n");
		exit(1);
	}

	fromatty = isatty(fileno(stdin));
	if (fromatty)
		verbose++;
	cpend = 0;	/* no pending replies */
	proxy = 0;	/* proxy not active */
	crflag = 1;	/* strip c.r. on ascii gets */
	sendport = -1;	/* not using ports */
	/*
	 * Set up the home directory in case we're globbing.
	 */
	(void) strcpy(home, _HOME);
/*	cp = getlogin();
	if (cp != NULL) {
		pw = getpwnam(cp);
	}
	if (pw == NULL)
		pw = getpwuid(getuid());
	if (pw != NULL) {
		home = homedir;
		(void) strcpy(home, pw->pw_dir);
	}
*/

#ifdef USE_SSL
	if (ssl_secure_flags & SSL_ENABLED) {
	    if (!do_ssleay_init(0)) {
		fprintf(stderr,"ftp: SSLeay initialisation failed\n");
		fflush(stderr);
		if (ssl_debug_flag) {
		    /* SKYNICK: it doesn't work under Win32...
		    ERR_print_errors_fp(stderr);*/
		    ERR_print_errors(bio_err);
		    BIO_flush(bio_err);
		}
		exit(1);
	    }
	}
#endif /* USE_SSL */

	if (argc > 0) {
		if (setjmp(toplevel))
			exit(0);
		(void) signal(SIGINT, intr);
		(void) signal(SIGPIPE, lostpeer);
		setpeer(argc + 1, argv - 1);
	}
	top = setjmp(toplevel) == 0;
	if (top) {
		(void) signal(SIGINT, intr);
		(void) signal(SIGPIPE, lostpeer);
	}
	for (;;) {
		cmdscanner(top);
		top = 1;
	}
}

void
intr(int i)
{

	longjmp(toplevel, 1);
}

void
lostpeer(int i)
{
	extern SOCKET s;
	extern int data;

	if (connected) {
		if (s > 0) {
			(void) shutdown(s, 1+1);
			(void) closesocket(s);
			s = 0;
		}
		if (data >= 0) {
			(void) shutdown(data, 1+1);
			(void) closesocket(data);
			data = -1;
		}
		connected = 0;
	}
	pswitch(1);
	if (connected) {
		if (s > 0) {
			(void) shutdown(s, 1+1);
			(void) closesocket(s);
			s = 0;
		}
		connected = 0;
	}
	proxflag = 0;
	pswitch(0);
}

/*char *
tail(filename)
	char *filename;
{
	register char *s;
	
	while (*filename) {
		s = rindex(filename, '/');
		if (s == NULL)
			break;
		if (s[1])
			return (s + 1);
		*s = '\0';
	}
	return (filename);
}
*/
/*
 * Command parser.
 */
void cmdscanner(top)
	int top;
{
	register struct cmd *c;
	register int l;
	struct cmd *getcmd();
	extern int help();

	if (!top)
		(void) putchar('\n');
	for (;;) {
		if (fromatty) {
			printf("ftps> ");
			(void) fflush(stdout);
		}
		if (fgets(line, sizeof line, stdin) == NULL)
			quit();
		l = strlen(line);
		if (l == 0)
			break;
		if (line[--l] == '\n') {
			if (l == 0)
				break;
			line[l] = '\0';
		} else if (l == sizeof(line) - 2) {
			printf("sorry, input line too long\n");
			while ((l = getchar()) != '\n' && l != EOF)
				/* void */;
			break;
		} /* else it was a line without a newline */
		makeargv();
		if (margc == 0) {
			continue;
		}
		c = getcmd(margv[0]);
		if (c == (struct cmd *)-1) {
			printf("?Ambiguous command\n");
			continue;
		}
		if (c == 0) {
			printf("?Invalid command\n");
			continue;
		}
		if (c->c_conn && !connected) {
			printf("Not connected.\n");
			continue;
		}
		(*c->c_handler)(margc, margv);
		if (bell && c->c_bell)
			(void) putchar('\007');
		if (c->c_handler != help)
			break;
	}
	(void) signal(SIGINT, intr);
	(void) signal(SIGPIPE, lostpeer);
}

struct cmd *
getcmd(name)
	register char *name;
{
	extern struct cmd cmdtab[];
	register char *p, *q;
	register struct cmd *c, *found;
	register int nmatches, longest;

	longest = 0;
	nmatches = 0;
	found = 0;
	for (c = cmdtab; p = c->c_name; c++) {
		for (q = name; *q == *p++; q++)
			if (*q == 0)		/* exact match? */
				return (c);
		if (!*q) {			/* the name was a prefix */
			if (q - name > longest) {
				longest = q - name;
				nmatches = 1;
				found = c;
			} else if (q - name == longest)
				nmatches++;
		}
	}
	if (nmatches > 1)
		return ((struct cmd *)-1);
	return (found);
}

/*
 * Slice a string up into argc/argv.
 */

int slrflag;

void makeargv()
{
	char **argp;
	char *slurpstring();

	margc = 0;
	argp = margv;
	stringbase = line;		/* scan from first of buffer */
	argbase = argbuf;		/* store from first of buffer */
	slrflag = 0;
	while (*argp++ = slurpstring())
		margc++;
}

/*
 * Parse string into argbuf;
 * implemented with FSM to
 * handle quoting and strings
 */
char *
slurpstring()
{
	int got_one = 0;
	register char *sb = stringbase;
	register char *ap = argbase;
	char *tmp = argbase;		/* will return this if token found */

	if (*sb == '!' || *sb == '$') {	/* recognize ! as a token for shell */
		switch (slrflag) {	/* and $ as token for macro invoke */
			case 0:
				slrflag++;
				stringbase++;
				return ((*sb == '!') ? "!" : "$");
				/* NOTREACHED */
			case 1:
				slrflag++;
				altarg = stringbase;
				break;
			default:
				break;
		}
	}

S0:
	switch (*sb) {

	case '\0':
		goto S4;

	case ' ':
	case '\t':
		sb++; goto S0;

	default:
		switch (slrflag) {
			case 0:
				slrflag++;
				break;
			case 1:
				slrflag++;
				altarg = sb;
				break;
			default:
				break;
		}
		goto S1;
	}

S1:
	switch (*sb) {

	case ' ':
	case '\t':
	case '\0':
		goto S4;	/* end of token */

/*	case '\\':
		sb++; goto S2;	/* slurp next character 
*/
	case '"':
		sb++; goto S3;	/* slurp quoted string */

	default:
		*ap++ = *sb++;	/* add character to token */
		got_one = 1;
		goto S1;
	}

/*S2:
	switch (*sb) {

	case '\0':
		goto S4;

	default:
		*ap++ = *sb++;
		got_one = 1;
		goto S1;
	}
*/
S3:
	switch (*sb) {

	case '\0':
		goto S4;

	case '"':
		sb++; goto S1;

	default:
		*ap++ = *sb++;
		got_one = 1;
		goto S3;
	}

S4:
	if (got_one)
		*ap++ = '\0';
	argbase = ap;			/* update storage pointer */
	stringbase = sb;		/* update scan pointer */
	if (got_one) {
		return(tmp);
	}
	switch (slrflag) {
		case 0:
			slrflag++;
			break;
		case 1:
			slrflag++;
			altarg = (char *) 0;
			break;
		default:
			break;
	}
	return((char *)0);
}

#define HELPINDENT (sizeof ("directory"))

/*
 * Help command.
 * Call each command handler with argc == 0 and argv[0] == name.
 */
int help(argc, argv)
	int argc;
	char *argv[];
{
	extern struct cmd cmdtab[];
	register struct cmd *c;

	if (argc == 1) {
		register int i, j, w, k;
		int columns, width = 0, lines;
		extern int NCMDS;

		printf("Commands may be abbreviated.  Commands are:\n\n");
		for (c = cmdtab; c < &cmdtab[NCMDS]; c++) {
			int len = strlen(c->c_name);

			if (len > width)
				width = len;
		}
		width = (width + 8) &~ 7;
		columns = 80 / width;
		if (columns == 0)
			columns = 1;
		lines = (NCMDS + columns - 1) / columns;
		for (i = 0; i < lines; i++) {
			for (j = 0; j < columns; j++) {
				c = cmdtab + j * lines + i;
				if (c->c_name && (!proxy || c->c_proxy)) {
					printf("%s", c->c_name);
				}
				else if (c->c_name) {
					for (k=0; k < (int)strlen(c->c_name); k++) {
						(void) putchar(' ');
					}
				}
				if (c + lines >= &cmdtab[NCMDS]) {
					printf("\n");
					break;
				}
				w = strlen(c->c_name);
				while (w < width) {
					w = (w + 8) &~ 7;
					(void) putchar('\t');
				}
			}
		}
		return 0;
	}
	while (--argc > 0) {
		register char *arg;
		arg = *++argv;
		c = getcmd(arg);
		if (c == (struct cmd *)-1)
			printf("?Ambiguous help command %s\n", arg);
		else if (c == (struct cmd *)0)
			printf("?Invalid help command %s\n", arg);
		else
			printf("%-*s\t%s\n", HELPINDENT,
				c->c_name, c->c_help);
	}
	return 0;
}
